#include "game.h"
#include "chasing_strategy.cpp"
#include <QRandomGenerator>
#define W (GameObject::Width)

Ghost::Ghost(int clr) : GameObject(
    GameObject::Ghost, QPixmap())
{
    color = (Color)clr;
    anim_index = 0;
    is_released = false;
    dir = Dir(QRandomGenerator::global()->generate() % 4);
    status = Normal;

       anim[Right].push_back(QPixmap(":/game_objects/sharks/sharkright1.png"));
       anim[Up].push_back(QPixmap(":/game_objects/sharks/sharkup1.png"));
       anim[Left].push_back(QPixmap(":/game_objects/sharks/sharkleft1.png"));
       anim[Down].push_back(QPixmap(":/game_objects/sharks/sharkdown1.png"));

       panic_anim.push_back(QPixmap(":/game_objects/sharks/sharkright-panic.png"));
       running_anim.push_back(QPixmap(":/game_objects/sharks/sharkup-panic.png"));

       setPixmap(anim[Right][0]);
}


Ghost::Color Ghost::get_color()
{
    return color;
}
